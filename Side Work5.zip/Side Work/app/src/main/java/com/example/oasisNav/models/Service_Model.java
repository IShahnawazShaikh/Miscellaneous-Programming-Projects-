package com.example.oasisNav.models;
import androidx.annotation.NonNull;
public class Service_Model {
    private String service_id, name, date, service_type, product_name, product_id;

    public Service_Model(String service_id, String name, String date, String service_type, String product_name, String product_id) {
        this.service_id = service_id;
        this.name = name;
        this.date = date;
        this.service_type = service_type;
        this.product_name = product_name;
        this.product_id = product_id;
    }

    public Service_Model() {
    }

    public String getService_id() {
        return service_id;
    }

    public void setService_id(String service_id) {
        this.service_id = service_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getService_type() {
        return service_type;
    }

    public void setService_type(String service_type) {
        this.service_type = service_type;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public String getProduct_id() {
        return product_id;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }

//    @Override
//    public int compareTo(Object o) {
//        String s1=((Service_Model)o).getService_id();
//        int id2=Integer.parseInt(s1);
//        int id1=Integer.parseInt(this.getService_id());
//        if(id1>id2)
//            return -1;
//        else if(id1<id2)
//            return +1;
//        else
//            return 0;
//    }
//    @NonNull
//    @Override
//    public String toString() {
//        return getService_id();
//    }

}
