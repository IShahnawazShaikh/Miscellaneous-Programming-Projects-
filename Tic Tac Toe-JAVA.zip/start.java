import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.Color;
class start implements ActionListener
{
  JFrame JF;
  JButton b1;
  JLabel JL1,JL2,JL3,background;
   JTextField JT1,JT2;
   start(){
    JF=new JFrame("Tic Tac Toe");
    JL1=new JLabel();  
    JL2=new JLabel();
    JL3=new JLabel();
    JT1=new JTextField();
    JT2=new JTextField();
    b1=new JButton("Start Game");

    JF.setSize(400,400);
    JF.setLayout(null);
	JL1.setText("Tic Tac Toe");
    JL1.setBounds(95,50,400,30);
    JL1.setForeground(Color.red);
    JL1.setFont(new Font("courier",Font.BOLD,30));
    JF.add(JL1);

      
      JL2.setText("Player1-Name:");
      JL2.setBounds(20,120,130,50);
      JL2.setForeground(Color.yellow);
      JL2.setFont(new Font("courier",Font.BOLD,16));
      JF.add(JL2);
      JT1.setBounds(160,135,160,30);
      JF.add(JT1);

      JL3.setText("Player2-Name:");
      JL3.setBounds(20,180,130,50);
      JL3.setForeground(Color.yellow);
      JL3.setFont(new Font("courier",Font.BOLD,16));
      JF.add(JL3);
      JT2.setBounds(160,190,160,30);
      JF.add(JT2);

      b1.setBounds(130,280,100,30);
      JF.add(b1);
      b1.addActionListener(this);
     

      ImageIcon icon=new ImageIcon("bk1.jpg");    
      Image img=icon.getImage();
	  Image img2=img.getScaledInstance(400,400,Image.SCALE_SMOOTH);
      icon=new ImageIcon(img2);
	  background=new JLabel("",icon,JLabel.CENTER);
      background.setBounds(0,0,400,400);
	  JF.add(background);

	  JF.setVisible(true);

    }
  public void actionPerformed(ActionEvent e){
  	   if(e.getSource()==b1){
  	   	   new game2(JT1.getText(),JT2.getText());
  	   	   JF.dispose();
  	   }
  }

  public static void main(String...x){
	 	 new start();
	 }
}