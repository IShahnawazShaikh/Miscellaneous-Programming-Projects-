import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.Color;
class game2 implements ActionListener{
	   JFrame JF;
	   JButton Btype2,Btype1,rst,rstN;
	   String player[]=new String[2];
	   JButton B[][]=new JButton[3][3]; 
	   JLabel JL1,JL2,JL3,JL4,JL5,JL6,background;
	   int k=0,counter=0,disable=0;
	   ActionEvent e;
     String symbol,pl1,pl2;
     String[][] value=new String[3][3];
	     int value2=0;
	   	  game2(String player1,String player2){
           pl1=player1;
           pl2=player2;
                JF=new JFrame();
                JL1=new JLabel(); 
                JL2=new JLabel(); 
                JL3=new JLabel("PLayer1: "+player1); 
                JL4=new JLabel("Player2: "+player2);
                JL5=new JLabel();
                JL6=new JLabel();

                JF.setSize(600,600);
				        JF.setLayout(null);
	            JL1.setText("Tic Tac Toe");
              JL1.setBounds(170,50,400,30);
              JL1.setForeground(Color.red);
              JL1.setFont(new Font("courier",Font.BOLD,30));
              JF.add(JL1);

              JL3.setBounds(30,100,250,30);
               JL3.setForeground(Color.red);
              JL3.setFont(new Font("courier",Font.BOLD,15));
              JF.add(JL3);
              
              JL5.setBounds(30,120,200,30);
              JF.add(JL5);

              JL4.setBounds(320,100,250,30);
              JL4.setForeground(Color.red);
              JL4.setFont(new Font("courier",Font.BOLD,15));
               JF.add(JL4);
              
               JL6.setBounds(320,120,200,30);
               JF.add(JL6);


              JL2.setText("Select Your Option");
	            JL2.setBounds(340,200,400,30);
	            JL2.setForeground(Color.green);
	            JL2.setFont(new Font("courier",Font.BOLD,18));
	            JF.add(JL2);
				for(int r=0;r<3;r++){
					if(r==0){ player[r]="";}
					  for(int c=0;c<3;c++){
					   B[r][c]=new JButton();
					 JF.add(B[r][c]);                                
					}
				}
				B[0][0].setBounds(30,160,80,80);
				B[0][1].setBounds(120,160,80,80);
				B[0][2].setBounds(210,160,80,80);

				B[1][0].setBounds(30,250,80,80);
				B[1][1].setBounds(120,250,80,80);
				B[1][2].setBounds(210,250,80,80);


				B[2][0].setBounds(30,340,80,80);
				B[2][1].setBounds(120,340,80,80);
				B[2][2].setBounds(210,340,80,80);
        
				Btype1=new JButton("X");
				Btype2=new JButton("O");
        rst=new JButton("Play Again");
				rstN=new JButton("New Game");
				Btype1.setBounds(390,240,50,50);
				Btype2.setBounds(390,310,50,50);
        rst.setBounds(70,450,140,30);
        rstN.setBounds(220,450,140,30);
				JF.add(Btype1);
				JF.add(Btype2);
				JF.add(rst);
        JF.add(rstN);

			  Btype1.addActionListener(this);
			  Btype2.addActionListener(this);
        rst.addActionListener(this);
			  rstN.addActionListener(this);
			  for(int i=0;i<3;i++){
			  	 for(int j=0;j<3;j++){
                    B[i][j].addActionListener(this);
			  	 }
			  }

    ImageIcon icon=new ImageIcon("bk2.jpg");    
    Image img=icon.getImage();
    Image img2=img.getScaledInstance(600,600,Image.SCALE_SMOOTH);
    icon=new ImageIcon(img2);
    background=new JLabel("",icon,JLabel.CENTER);
    background.setBounds(0,0,600,600);
    JF.add(background);

	     JF.setVisible(true);   
	   }
public void actionPerformed(ActionEvent e2){
   e=e2;
    if(e.getSource()==Btype1){
      k=0;
	   player[k]="X";
     JL5.setText("Symbol: "+player[k]);
		 ++k;
	   player[k]="O";
     JL6.setText("Symbol: "+player[k]);
		  k=0;
		  System.out.println("palyer-1:"+player[0]);
      System.out.println("player-2:"+player[1]);
	   }
	   else if(e.getSource()==Btype2){
			  k=0;
			  player[k]="O";
        JL5.setText("Symbol: "+player[k]);
			  ++k;
			  player[k]="X";
        JL6.setText("Symbol: "+player[k]);
			  k=0;
			  System.out.println("palyer-1:"+player[0]);
        System.out.println("player-2:"+player[1]);
	   }
	 else if(e.getSource()==rst){
	 	value2=0;
	 	disable=0;
     Btype1.setEnabled(true);
    Btype2.setEnabled(true);
	 	B[0][0].setEnabled(true);
	 	B[0][1].setEnabled(true);
	 	B[0][2].setEnabled(true);
	 	B[1][0].setEnabled(true);
	 	B[1][1].setEnabled(true);
	 	B[1][1].setEnabled(true);
	 	B[1][2].setEnabled(true);
	 	B[2][0].setEnabled(true);
	 	B[2][1].setEnabled(true);
	 	B[2][2].setEnabled(true);
	  System.out.println("reset");
	  for(int r=0;r<3;r++){
      	for(int c=0;c<3;c++){
             B[r][c].setText("");
      	}
      }
      player[0]="";
      player[1]="";
      JL5.setText("");
      JL6.setText("");
	 	  //matchProcess();
    }
  else if(e.getSource()==rstN){
      new start();
      JF.dispose();
  }

   else{
           matchProcess();
      	}         //esle close
   }
 void matchProcess(){
   counter=0; 
 if(player[0].equals("")){System.out.println("First Select the player");}
  else{
    Btype1.setEnabled(false);
    Btype2.setEnabled(false);
     for(int r=0;r<3;r++){
      	for(int c=0;c<3;c++){
           if(e.getSource()==B[r][c]){
             B[r][c].setText(player[k]);
		          symbol=player[k];
		           B[r][c].setEnabled(false);
                  disable=disable+1;
                  value2=value2+1;
                  k++;
                  if(k==2){
                     k=0;
                  }
		         if(value2>4){                        
                     
                     process(disable,symbol);

                 }
     }
   }
  }
 }
}
 
void process(int disable,String symbol){
  for(int p=0;p<3;p++){
      for(int q=0;q<3;q++){
          value[p][q]=B[p][q].getText();
      }
  }
     if (value[0][0].equals(value[0][1]) && value[0][1].equals(value[0][2]) && !value[0][2].equals("") ||
         value[1][0].equals(value[1][1]) && value[1][1].equals(value[1][2]) && !value[1][2].equals("") ||
         value[2][0].equals(value[2][1]) && value[2][1].equals(value[2][2]) && !value[2][2].equals("") ||

         value[0][0].equals(value[1][0]) && value[1][0].equals(value[2][0]) && !value[2][0].equals("") ||
         value[0][1].equals(value[1][1]) && value[1][1].equals(value[2][1]) && !value[2][1].equals("") ||
         value[0][2].equals(value[1][2]) && value[1][2].equals(value[2][2]) && !value[2][2].equals("") ||

         value[0][0].equals(value[1][1]) && value[1][1].equals(value[2][2]) && !value[2][2].equals("") ||
         value[0][2].equals(value[1][1]) && value[1][1].equals(value[2][0]) && !value[2][0].equals("")) {
          if(player[0].equals(symbol)){
            System.out.println(pl1+" Won The Game");
          }
          else{
             System.out.println(pl2+" Won The Game");  
          }
          for(int p=0;p<3;p++){
            for(int q=0;q<3;q++){
              B[p][q].setEnabled(false);
            }
          }
      }
     else{
      if(disable==9){

         System.out.println("Match Tie");
        }   
     }
}
 public static void main(String...x){
       //new game2("shahnawaz","Shahnawaz2");
	 }
}