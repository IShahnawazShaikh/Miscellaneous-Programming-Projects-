package com.example.shahnawazshaikh.qrinfocoded;

import android.app.Activity;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;
public class MainActivity extends AppCompatActivity {
    Button GenerateButton;
    EditText name,id;
    ImageView myImg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name=(EditText) findViewById(R.id.name);
        id=(EditText) findViewById(R.id.id);
         myImg=(ImageView)findViewById(R.id.QRCod);
        final Activity activity=this;
        GenerateButton=(Button) findViewById(R.id.GenerateButton);
        GenerateButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
               if (name.getText().toString().equals("") || id.getText().toString().equals("")) {
                    Toast.makeText(getApplicationContext(), "Must fill" + name.getText().toString(), Toast.LENGTH_SHORT).show();
               } else {
                    try {
                        BitMatrix bitMatrix = multiFormatWriter.encode("Name: " + name.getText().toString() + "\nYour Id: " + id.getText().toString(), BarcodeFormat.QR_CODE, 350, 350);
                        BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
                        Bitmap bitmap = barcodeEncoder.createBitmap(bitMatrix);
                        myImg.setImageBitmap(bitmap);
                    } catch (WriterException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }
}
