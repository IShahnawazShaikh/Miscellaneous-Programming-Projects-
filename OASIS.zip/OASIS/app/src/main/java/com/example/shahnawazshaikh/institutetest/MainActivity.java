package com.example.shahnawazshaikh.institutetest;

import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button HeadManager,ServiceMan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        HeadManager=findViewById(R.id.HeadManager);
        ServiceMan=findViewById(R.id.ServiceMan);


        HeadManager.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,Manager_Login.class);
                startActivity(intent);
            }
        });
        ServiceMan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,Service_Man_Login.class);
                startActivity(intent);
            }
        });
    }


}