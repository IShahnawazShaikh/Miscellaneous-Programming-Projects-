import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.sql.Connection;
public class DataEntryUpdate implements ActionListener
{    
	  JFrame frame;
	 JLabel JL,JL2,JL3,JL4,JL5,JL6,JL7,JL8,JL9,JL10,JL11,background,JL12;
	 JTextField JT1,JT2,JT3,JT4,JT5,JT6,JT7,JT8,JT9,JT10;
	 JButton JB1,JB2;
	 String name,JM,enroll,email,phone,s1,s2,s3,s4;
	 Statement st;
	 String ID2;
	 ResultSet rs;
	 String[] value=new String[9];
	 DataEntryUpdate(String ID,ResultSet Rs)
	{
		this.ID2=ID;
		this.rs=Rs;
		try{
			for(int i=0;i<9;i++){
				value[i]=rs.getString(i+1);
			}
		}
		catch(Exception e){}


    frame=new JFrame("Student Management System");
  	  frame.setSize(500,750);
	   frame.setVisible(true);
	   frame.setLayout(null);
	  ImageIcon icon=new ImageIcon("student3.jpg");    
      Image img=icon.getImage();
	  Image img2=img.getScaledInstance(500,750,Image.SCALE_SMOOTH);
      icon=new ImageIcon(img2);
	  background=new JLabel("",icon,JLabel.CENTER);
      background.setBounds(0,0,500,700);
	  frame.add(background);

	   JL=new JLabel(); 
	   JL.setText("Student Database Management System");
	   JL.setBounds(60,50,380,30);
	   JL.setForeground(Color.RED);
	   JL.setFont(new Font("courier",Font.BOLD,18));
	   background.add(JL);
	   frame.add(background); 


        JL2=new JLabel();
		JL2.setText("Name:");
        JL2.setForeground(Color.YELLOW);
		JL2.setBounds(70,110,70,30);                    //label-Name
        background.add(JL2);
   
	   JT1=new JTextField();                                  //Name-Field
       JT1.setBounds(145,110,200,30);
       JT1.setVisible(true);
	   frame.add(JT1);

        JL3=new JLabel();
		JL3.setText("JMI-ID:");
        JL3.setForeground(Color.YELLOW);
		JL3.setBounds(70,160,70,30);                    //label-JMI-ID
        background.add(JL3);
   
	   JT2=new JTextField();                                  //JMI-ID-Field
       JT2.setBounds(145,160,200,30);
       JT2.setVisible(true);
	   frame.add(JT2);
  
        JL4=new JLabel();
		JL4.setText("Enroll No:");
        JL4.setForeground(Color.YELLOW);
		JL4.setBounds(70,210,70,30);                    //label-Enroll
        background.add(JL4);
   
	   JT3=new JTextField();                                   //FIeld-Enroll
       JT3.setBounds(145,210,200,30);
       JT3.setVisible(true);
	   frame.add(JT3);
     
	    JL5=new JLabel();
		JL5.setText("Email:");
        JL5.setForeground(Color.YELLOW);
		JL5.setBounds(70,260,70,30);                    //label-Email
        background.add(JL5);
   
	   JT4=new JTextField();                                   //FIeld-Email
       JT4.setBounds(145,260,200,30);
       JT4.setVisible(true);
	   frame.add(JT4);
    

       JL6=new JLabel();
		JL6.setText("Phone:");
        JL6.setForeground(Color.YELLOW);
		JL6.setBounds(70,310,70,30);                    //label-Phone
        background.add(JL6);
   
	   JT5=new JTextField();                                   //FIeld-Phone
       JT5.setBounds(145,310,200,30);
       JT5.setVisible(true);
	   frame.add(JT5);

       
         JL7=new JLabel();
		JL7.setText("Smester Marks Details:");
        JL7.setForeground(Color.YELLOW);
		JL7.setBounds(70,360,200,30);                    //label-Semester Marks
        background.add(JL7);
   
	   
        JL8=new JLabel();
		JL8.setText("Sem-1:");
        JL8.setForeground(Color.YELLOW);
		JL8.setBounds(70,410,70,30);                    //label-Sem-1
        background.add(JL8);
   
	   JT6=new JTextField();                                   //FIeld-Sem-1
       JT6.setBounds(145,410,50,30);
       JT6.setVisible(true);
	   frame.add(JT6);



	   
        JL9=new JLabel();
		JL9.setText("Sem-2:");
        JL9.setForeground(Color.YELLOW);
		JL9.setBounds(220,410,70,30);                    //label-Sem-2
        background.add(JL9);
   
	   JT7=new JTextField();                                   //FIeld-Sem-2
       JT7.setBounds(295,410,50,30);
       JT7.setVisible(true);
	   frame.add(JT7);


	   
        JL10=new JLabel();
		JL10.setText("Sem-3:");
        JL10.setForeground(Color.YELLOW);
		JL10.setBounds(70,520,70,30);                    //label-Sem-3
        background.add(JL10);
   
	   JT8=new JTextField();                                   //FIeld-Sem-3
       JT8.setBounds(145,520,40,30);
       JT8.setVisible(true);
	   frame.add(JT8);

      JL11=new JLabel();
		JL11.setText("Sem-2:");
        JL11.setForeground(Color.YELLOW);
		JL11.setBounds(220,520,70,30);                    //label-Sem-4
        background.add(JL11);
   
	   JT9=new JTextField();                                   //FIeld-Sem-4
       JT9.setBounds(295,520,40,30);
       JT9.setVisible(true);
	   frame.add(JT9);

      JB1=new JButton("Update");
	  JB1.setBounds(180,580,100,30);              //Submit
	   JB1.setBackground(Color.CYAN);
       JB1.setForeground(Color.BLACK);
	    background.add(JB1);
     
     

      JB2=new JButton("Backward");
	  JB2.setBounds(40,650,100,30);                     //Backward
	   JB2.setBackground(Color.RED);
       JB2.setForeground(Color.BLACK);
	    background.add(JB2);

        JL11=new JLabel();
		JL11.setText("Status:");
        JL11.setForeground(Color.YELLOW);
		JL11.setBounds(310,590,50,30);                    //label-Status
        background.add(JL11);

	   JT10=new JTextField();                                   //Updated
       JT10.setBounds(310,620,100,30);
       JT10.setVisible(true);
	   frame.add(JT10);
   
   
     JB2.addActionListener(this);
	 JB1.addActionListener(this);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
	  public void actionPerformed(ActionEvent e){
      
      for(int i=0;i<9;i++){
            	 System.out.println(value[i]);
            }
	     if(e.getSource()==JB2){
			 frame.dispose();
			 new loginUpdate();
		 }

		 if(e.getSource()==JB1){
   
             try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("okie");
			Connection cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","s9716946677s");
			System.out.println("ok-1");
			Statement st=cn.createStatement();
	       	 
               if(JT1.getText().equals("")){}
			   else
				   value[0]=JT1.getText();


			    if(JT2.getText().equals("")){}
			   else
				   value[1]=JT2.getText();

			    if(JT3.getText().equals("")){}
			   else
				   value[2]=JT3.getText();


			    if(JT4.getText().equals("")){}
			   else
				   value[3]=JT1.getText();


			    if(JT5.getText().equals("")){}
			   else
				   value[4]=JT5.getText();

			    if(JT6.getText().equals("")){}
			   else
				   value[5]=JT6.getText();


			    if(JT7.getText().equals("")){}
			   else
				   value[6]=JT7.getText();

			    
			   if(JT8.getText().equals("")){}
			   else
				   value[7]=JT8.getText();

			    if(JT9.getText().equals("")){}
			   else
			 value[8]=JT9.getText();

			 String query = "update StudentTable set Name='"+value[0]+"',JM_ID='"+value[1]+"', Enroll='"+value[2]+"', email='"+value[3]+"', phone='"+value[4]+"', Sem_1='"+value[5]+"', Sem_2='"+value[6]+"', Sem_3='"+value[7]+"', Sem_4='"+value[8]+"' where  JM_ID='"+ID2+"' ";

               st.executeQuery(query);
			  JT1.setText("");
			   JT2.setText("");
			   JT3.setText("");
			   JT4.setText("");
			   JT5.setText("");
				JT6.setText("");
				JT7.setText("");
				JT8.setText("");
				JT9.setText("");
              JT10.setText("Updated");
           } 
		   catch (Exception p) {
			   p.printStackTrace();
		    }  

	 }     //if
}


}
