import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class adminPage implements ActionListener
{
	 JFrame frame;
	 JLabel JL,background;
	 JButton JB1,JB2,JB3,JB4;
	adminPage(){

     frame=new JFrame("Admin Page");
	  frame.setSize(500,500);
	   frame.setVisible(true);
	   frame.setLayout(null);
	  ImageIcon icon=new ImageIcon("student1.png");    
      Image img=icon.getImage();
	  Image img2=img.getScaledInstance(500,500,Image.SCALE_SMOOTH);
      icon=new ImageIcon(img2);
	  background=new JLabel("",icon,JLabel.CENTER);
      background.setBounds(0,0,500,500);
	  frame.add(background);

	   JL=new JLabel(); 
	   JL.setText("Student Database Management System");
	   JL.setBounds(60,50,380,30);
	   JL.setForeground(Color.RED);
	   JL.setFont(new Font("courier",Font.BOLD,18));
	   background.add(JL);
	   frame.add(background); 

       
       JB1=new JButton("Add Student Infromation");
       JB1.setBounds(130,110,190,30);
       JB1.setBackground(Color.CYAN);
       JB1.setForeground(Color.BLACK);
       frame.add(JB1);
         
       JB2=new JButton("Update Student Infromation");
       JB2.setBounds(130,160,190,30);
       JB2.setBackground(Color.CYAN);
       JB2.setForeground(Color.BLACK);
       frame.add(JB2);

       JB3=new JButton("Delete Student Infromation");
       JB3.setBounds(130,210,190,30);
       JB3.setBackground(Color.CYAN);
       JB3.setForeground(Color.BLACK);
       frame.add(JB3);


       JB4=new JButton("Backward");              //Button-4
	   JB4.setBounds(30,400,100,35);
	   JB4.setBackground(Color.RED);
       JB4.setForeground(Color.BLACK);
       frame.add(JB4);
       
	   JB1.addActionListener(this);
	   JB2.addActionListener(this);
	   JB3.addActionListener(this);
	   JB4.addActionListener(this);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==JB1){
			frame.dispose();
			new DataEntry();
		}

		if(e.getSource()==JB2){
			System.out.println("update call");
		  //   frame.dispose();
			 new loginUpdate(); 
		}
        if(e.getSource()==JB3){
		   new loginDelete();
		}
		if(e.getSource()==JB4){
		    new adminLogin();
		}
     
    } 
   
}