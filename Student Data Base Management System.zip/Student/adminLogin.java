import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.sql.Connection;
public class adminLogin implements ActionListener
	{
	  JFrame frame;
	 JTextField JT1;
	 JLabel JL,JL2,JL3,background;
	 JPasswordField JT2;
	 JButton JB,JB2;
	 Statement st;
	 Connection cn;
	 ResultSet rs;
	 String adminId;
	 String password;
	 int counter=0;
      adminLogin(){
	  
	  frame=new JFrame("Admin Login");
	  frame.setSize(500,500);
	   frame.setVisible(true);
	   frame.setLayout(null);
	  ImageIcon icon=new ImageIcon("student1.png");    
      Image img=icon.getImage();
	  Image img2=img.getScaledInstance(500,500,Image.SCALE_SMOOTH);
      icon=new ImageIcon(img2);
	  background=new JLabel("",icon,JLabel.CENTER);
      background.setBounds(0,0,500,500);
	  frame.add(background);

	   JL=new JLabel(); 
	   JL.setText("Student Database Management System");
	   JL.setBounds(60,50,380,30);
	   JL.setForeground(Color.RED);
	   JL.setFont(new Font("courier",Font.BOLD,18));
	   background.add(JL);
	   frame.add(background); 



	    JL2=new JLabel();
		JL2.setText("Admin ID:");
        JL2.setForeground(Color.YELLOW);
		JL2.setBounds(70,110,70,30);                    //label-Admin-id
        background.add(JL2);
   
	   JT1=new JTextField();                                  //ID-field
       JT1.setBounds(145,110,200,30);
       JT1.setVisible(true);
	   frame.add(JT1);
     


        JL3=new JLabel();
		JL3.setText("Password:");
		JL3.setForeground(Color.YELLOW);
		JL3.setBounds(70,160,70,30);                        //label-Password
        background.add(JL3);
	   //frame.add(background); 
   
	   JT2=new JPasswordField();                          //Passworld-field
       JT2.setBounds(145,160,200,30);
       JT2.setVisible(true);
	   frame.add(JT2);
      

	   JB=new JButton("Go To Admin Page");         //Button-admin-page
	   JB.setBounds(160,240,140,35);
	   JB.setBackground(Color.CYAN);
       JB.setForeground(Color.BLACK);
       frame.add(JB);

       JB2=new JButton("Backward");                    //Button-backward
	   JB2.setBounds(30,400,110,35);
	   JB2.setBackground(Color.RED);
       JB2.setForeground(Color.BLACK);
       frame.add(JB2);

       JB.addActionListener(this);
       JB2.addActionListener(this);

     frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   }

   public void actionPerformed(ActionEvent e){
     if(e.getSource()==JB){
		  try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			 cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","s9716946677s");
		     st=cn.createStatement();
			  rs=st.executeQuery("select * from AdminTable");
			  while(rs.next()){
			   adminId=rs.getString(1);
			   password=rs.getString(2);
			      if(JT1.getText().equals(adminId) && JT2.getText().equals(password)){
			    	  System.out.println("varified");
				      ++counter;
				  }
			   	  if(counter==1){
					  frame.dispose();
			   	      new adminPage();
					  cn.close();
					  break;
				   }
			   }//while close
			   if(counter==0)
			    	System.out.println("Wrong ID or Password");
		  } 
		catch (Exception p) {
			p.printStackTrace();
		    }
        }
    if(e.getSource()==JB2){
    	frame.dispose();
    	 new student();
    }

   }
    
}