import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.sql.Connection;
public class detailLogin implements ActionListener
{
	  JFrame frame;
	 JLabel JL,background,JL2;
	 JTextField JT1;
	 JButton JB1,JB2;

	  Statement st;
	 Connection cn;
	 ResultSet rs;
	 String password;
	 int counter=0;
	 detailLogin(){
        frame=new JFrame("Student Management System");
	  frame.setSize(500,500);
	   frame.setVisible(true);
	   frame.setLayout(null);
	  ImageIcon icon=new ImageIcon("laptop.jpg");    
      Image img=icon.getImage();
	  Image img2=img.getScaledInstance(500,500,Image.SCALE_SMOOTH);
      icon=new ImageIcon(img2);
	  background=new JLabel("",icon,JLabel.CENTER);
      background.setBounds(0,0,500,500);
	  frame.add(background);

	   JL=new JLabel(); 
	   JL.setText("Student Database Management System");
	   JL.setBounds(60,50,380,30);
	   JL.setForeground(Color.RED);
	   JL.setFont(new Font("courier",Font.BOLD,18));
	   background.add(JL);
	   frame.add(background); 
     
	    
       JL2=new JLabel(); 
	   JL2.setText("JMI-ID:");
	   JL2.setBounds(100,120,100,30);
	   JL2.setForeground(Color.BLACK);
	   //JL2.setFont(new Font("courier",Font.BOLD,18));
	   background.add(JL2);
	   frame.add(background); 
      

	   JT1=new JTextField();
       JT1.setBounds(200,120,100,30);
	   frame.add(JT1);

	   JB1=new JButton("Get Details"); 
       JB1.setBounds(200,200,150,30);             //Detail
       JB1.setBackground(Color.CYAN);
       JB1.setForeground(Color.BLACK);
       frame.add(JB1);

	    JB2=new JButton("Backward");                    //Button-backward
	   JB2.setBounds(30,400,110,35);
	   JB2.setBackground(Color.RED);
       JB2.setForeground(Color.BLACK);
       frame.add(JB2);
	   
	   JB1.addActionListener(this);
	   JB2.addActionListener(this);
       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	 }
	 public void actionPerformed(ActionEvent e){
          if(e.getSource()==JB1){
          	  try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			 cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","s9716946677s");
		     st=cn.createStatement();
			  rs=st.executeQuery("select * from StudentTable");
			  while(rs.next()){
			     password=rs.getString(2);   //2->column number
			         if(password.equals(JT1.getText())){
						 ++counter;
					 }
					 if(counter==1){  
						 frame.dispose();                                   //logic
			             new ShowDetail(rs);
						  cn.close();
						  break;
						}
			  }
			  if(counter==0)
			  System.out.println(JT1.getText()+" Doesn't Exist");
		} 
		catch (Exception p) {
			p.printStackTrace();
		   }
 
      }     //if close
		 if(e.getSource()==JB2){
           frame.dispose();
		   new student();
		 }

	 }
	 

}