import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
public class connection
{
	 public static void main(String...x){
       
	   try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("okie");
			Connection cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","s9716946677s");
			System.out.println("ok-1");
			Statement st=cn.createStatement();
	       	st.executeUpdate("create table AdminTable2(AdminId varchar2(20),Password varchar2(20))");
                  st.executeUpdate("INSERT INTO AdminTable2(AdminId,Password)  VALUES ('JM786JAVA', 'jamia')");
		} 
		catch (Exception p) {
			p.printStackTrace();
		}
	 }
}