import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class student implements ActionListener
{
	 JFrame frame;
	 JLabel JL,background,JL1,JL2;
	 JButton JB1,JB2;
	  student(){

	  frame=new JFrame("Student Management System");
	  frame.setSize(500,500);
	   frame.setVisible(true);
	   frame.setLayout(null);
	  ImageIcon icon=new ImageIcon("student1.png");    
      Image img=icon.getImage();
	  Image img2=img.getScaledInstance(500,500,Image.SCALE_SMOOTH);
      icon=new ImageIcon(img2);
	  background=new JLabel("",icon,JLabel.CENTER);
      background.setBounds(0,0,500,500);
	  frame.add(background);

	   JL=new JLabel(); 
	   JL.setText("Student Database Management System");
	   JL.setBounds(60,50,480,30);
	   JL.setForeground(Color.RED);
	   JL.setFont(new Font("courier",Font.BOLD,20));
	   background.add(JL);
	   frame.add(background); 

	 
       
	   JB1=new JButton("Admin Section"); 
       JB1.setBounds(130,130,200,30);
       JB1.setBackground(Color.CYAN);
       JB1.setForeground(Color.BLACK);
       frame.add(JB1);
    
	   JB2=new JButton("Student Information Section");
	   JB2.setBounds(130,180,200,30);
	   JB2.setBackground(Color.CYAN);
       JB2.setForeground(Color.BLACK);
	   frame.add(JB2);
    

	   JL1=new JLabel(); 
	   JL1.setText("Developed By:");
	   JL1.setBounds(60,320,300,30);
	   JL1.setForeground(Color.RED);
	   JL1.setFont(new Font("courier",Font.BOLD,22));
	   background.add(JL1);
	   frame.add(background); 

	  
       JL2=new JLabel(); 
	   JL2.setText("Shahnawaz Shaikh");
	   JL2.setBounds(70,380,300,30);
	   JL2.setForeground(Color.BLACK);
	   JL2.setFont(new Font("courier",Font.BOLD,17));
	   background.add(JL2);
	   frame.add(background);
	   
	   

      JB1.addActionListener(this);
	  JB2.addActionListener(this);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	  }

  public void actionPerformed(ActionEvent e){
    
	   if(e.getSource()==JB1){
           frame.dispose();
           new adminLogin();
	   }

	   if(e.getSource()==JB2){
          frame.dispose();
		  new detailLogin();
	   }
  }

	 public static void main(String...x){
         new student();
	 }
}