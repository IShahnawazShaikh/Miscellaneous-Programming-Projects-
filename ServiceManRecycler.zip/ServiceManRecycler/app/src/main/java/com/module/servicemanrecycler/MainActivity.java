package com.module.servicemanrecycler;


import android.os.Bundle;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {
    private static String REGISTER_URL="https://ingratiating-jacks.000webhostapp.com/Oasis/ServiceMan_Recycler.php";
    RecyclerView recyclerView;
    List list;
    RequestQueue requestQueue;
    LinearLayoutManager manager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       recyclerView=findViewById(R.id.recycler1);
        recyclerView.setHasFixedSize(true);
        manager=new LinearLayoutManager(this);
        recyclerView.setLayoutManager(manager);
      // recyclerView.addItemDecoration(new SpacesItemDecoration(10,1));
        list = new ArrayList<>();
        fetchDetails();
    }
    private void fetchDetails() {
        Cache cache = new DiskBasedCache(getApplication().getCacheDir(), 1024 * 1024 * 5);
        Network network = new BasicNetwork(new HurlStack());
        requestQueue = new RequestQueue(cache, network);
        requestQueue.start();
        StringRequest stringRequest = new StringRequest(Request.Method.GET, REGISTER_URL,
                response -> {
                    try {
                        JSONArray array = new JSONArray(response);
                        for (int i = 0; i < array.length(); i++) {
                            JSONObject detail = array.getJSONObject(i);
                            list.add(new Items(detail.getString("first_name"), detail.getString("last_name"), detail.getString("email"),detail.getString("phone"),detail.getString("id")));
                        }
                        ItemsAdapter adapter = new ItemsAdapter(getApplicationContext(),list);
                        recyclerView.setAdapter(adapter);
                        //recyclerView1.setAdapter(adapter);
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(getApplicationContext(), "Error" + e.toString(), Toast.LENGTH_SHORT).show();
                    }
                }, error -> Toast.makeText(getApplicationContext(),""+error.toString(),Toast.LENGTH_LONG).show()
        );
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
            }
        });
        requestQueue.add(stringRequest);
      }
}
