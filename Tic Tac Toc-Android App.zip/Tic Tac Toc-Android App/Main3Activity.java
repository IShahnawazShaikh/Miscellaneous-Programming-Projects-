package com.example.shahnawazshaikh.tictactoe;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Main3Activity extends AppCompatActivity {
    EditText name1,name2;
    Button start;

    static String firstName,secondName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        name1=findViewById(R.id.name1);
        name2=findViewById(R.id.name2);
        start=findViewById(R.id.start);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 firstName= String.valueOf(name1.getText());
                 secondName= String.valueOf(name2.getText());
                 Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                 startActivity(intent);
            }

        });

    }
    /*public String getData1(){
         return firstName;
    }
    public String getData2(){
        return secondName;
    }*/

}
