package com.example.shahnawazshaikh.tictactoe;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btx,bto,bt1,bt2,bt3,bt4,bt5,bt6,bt7,bt8,bt9,bt10,bt11;
    EditText pb1,pb2,pName1,pName2;
    CharSequence[] player=new CharSequence[2];
    int k=0,pCounter=0;
    static int checkvalue=0;
    CharSequence value="null";
    String s1,s2,pbs1,pbs2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
         s1 = Main3Activity.firstName;
         s2 = Main3Activity.secondName;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btx=(Button)findViewById(R.id.X);
        bto=(Button)findViewById(R.id.O);
        bt1=(Button)findViewById(R.id.b1);
        bt2=(Button)findViewById(R.id.b2);
        bt3=(Button)findViewById(R.id.b3);
        bt4=(Button)findViewById(R.id.b4);
        bt5=(Button)findViewById(R.id.b5);
        bt6=(Button)findViewById(R.id.b6);
        bt7=(Button)findViewById(R.id.b7);
        bt8=(Button)findViewById(R.id.b8);
        bt9=(Button)findViewById(R.id.b9);
        bt10=(Button)findViewById(R.id.b10);
        bt11=(Button)findViewById(R.id.b11);
        pb1=(EditText)findViewById(R.id.p1);
        pb2=(EditText)findViewById(R.id.p2);
//        pbs1=String.valueOf(pb1.getText());
//        pbs2=String.valueOf(pb1.getText());

//        Toast.makeText(MainActivity.this,"Symbol-1"+pbs1,Toast.LENGTH_LONG).show();
//        Toast.makeText(MainActivity.this,"Symbol-2"+pbs2,Toast.LENGTH_LONG).show();

        pName1=(EditText)findViewById(R.id.pName1);
        pName2=(EditText)findViewById(R.id.pName2);

        pName1.setText(s1);
        pName2.setText(s2);
        pName1.setEnabled(false);
        pName2.setEnabled(false);
        pb1.setEnabled(false);
        pb2.setEnabled(false);

        btx.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pb1.setEnabled(true);
                pb2.setEnabled(true);
                k=0;
                player[k]=btx.getText();
                pb1.setText(player[k]);
                pbs1=String.valueOf(pb1.getText());
                ++k;
                player[k]=bto.getText();
                pb2.setText(player[k]);
                pbs2=String.valueOf(pb2.getText());
                k=0;
                pb1.setEnabled(false);
                pb2.setEnabled(false);
                pCounter++;
            }
        });
        bto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pb1.setEnabled(true);
                pb2.setEnabled(true);
                k=0;
                player[k]=bto.getText();
                pb1.setText(player[k]);
                pbs1=String.valueOf(pb1.getText());
                ++k;
                player[k]=btx.getText();
                pb2.setText(player[k]);
                pbs2=String.valueOf(pb2.getText());
                k=0;
                pb1.setEnabled(false);
                pb2.setEnabled(false);
                pCounter++;
            }
        });

     bt1.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             if (pCounter != 0) {
                 bt1.setText(player[k]);
                 value = player[k];

                 ++k;
                 checkvalue++;
                 if (k == 2) {
                     k = 0;
                 }
                 if (checkvalue >= 4) {

                     process(checkvalue);
                 }
                 bt1.setEnabled(false);
                 btx.setEnabled(false);
                 bto.setEnabled(false);
             }
             else{
                 Toast.makeText(MainActivity.this,"Select Player",Toast.LENGTH_SHORT).show();
             }

         }
     });

     bt2.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             if (pCounter != 0) {
                 bt2.setText(player[k]);
                 value = player[k];

                 ++k;
                 checkvalue++;
                 if (k == 2) {
                     k = 0;
                 }
                 if (checkvalue >= 4) {
                     process(checkvalue);
                 }
                 bt2.setEnabled(false);
                 btx.setEnabled(false);
                 bto.setEnabled(false);
             }
             else{
                 Toast.makeText(MainActivity.this,"Select Player",Toast.LENGTH_SHORT).show();
             }
         }

     });

        bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pCounter != 0) {
                    bt3.setText(player[k]);
                    value = player[k];

                    ++k;
                    checkvalue++;
                    if (k == 2) {
                        k = 0;
                    }
                    if (checkvalue >= 4) {
                        process(checkvalue);
                    }
                    bt3.setEnabled(false);
                    btx.setEnabled(false);
                    bto.setEnabled(false);
                }
                else{
                    Toast.makeText(MainActivity.this,"Select Player",Toast.LENGTH_SHORT).show();
                }
            }

        });

        bt4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pCounter != 0) {
                    bt4.setText(player[k]);
                    value = player[k];

                    ++k;
                    checkvalue++;
                    if (k == 2) {
                        k = 0;
                    }
                    if (checkvalue >= 4) {
                        process(checkvalue);
                    }
                    bt4.setEnabled(false);
                    btx.setEnabled(false);
                    bto.setEnabled(false);
                }
                else{
                    Toast.makeText(MainActivity.this,"Select Player",Toast.LENGTH_SHORT).show();
                }
            }

        });

        bt5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pCounter != 0) {
                    bt5.setText(player[k]);
                    value = player[k];

                    ++k;
                    checkvalue++;
                    if (k == 2) {
                        k = 0;
                    }
                    if (checkvalue >= 4) {
                        process(checkvalue);
                    }
                    bt5.setEnabled(false);
                    btx.setEnabled(false);
                    bto.setEnabled(false);
                }
                else{
                    Toast.makeText(MainActivity.this,"Select Player",Toast.LENGTH_SHORT).show();
                }
            }

        });

        bt6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pCounter != 0) {
                    bt6.setText(player[k]);
                    value = player[k];

                    ++k;
                    checkvalue++;
                    if (k == 2) {
                        k = 0;
                    }
                    if (checkvalue >= 4) {
                        process(checkvalue);
                    }
                    bt6.setEnabled(false);
                    btx.setEnabled(false);
                    bto.setEnabled(false);
                }
                else{
                    Toast.makeText(MainActivity.this,"Select Player",Toast.LENGTH_SHORT).show();
                }
            }

        });
        bt7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pCounter != 0) {
                    bt7.setText(player[k]);
                    value = player[k];
                    ++k;
                    checkvalue++;
                    if (k == 2) {
                        k = 0;
                    }
                    if (checkvalue >= 4) {
                        process(checkvalue);
                    }
                    bt7.setEnabled(false);
                    btx.setEnabled(false);
                    bto.setEnabled(false);
                }
                else{
                    Toast.makeText(MainActivity.this,"Select Player",Toast.LENGTH_SHORT).show();
                }
            }

        });


        bt8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pCounter != 0) {
                    bt8.setText(player[k]);
                    value = player[k];
                    ++k;
                    checkvalue++;
                    if (checkvalue >= 4) {
                        process(checkvalue);
                    }
                    if (k == 2) {
                        k = 0;
                    }

                    bt8.setEnabled(false);
                    btx.setEnabled(false);
                    bto.setEnabled(false);
                }
            }
        });

        bt9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pCounter != 0) {
                    bt9.setText(player[k]);
                    value = player[k];

                    ++k;
                    checkvalue++;
                    if (checkvalue >= 4) {
                        process(checkvalue);
                    }
                    if (k == 2) {
                        k = 0;
                    }
                    bt9.setEnabled(false);
                    btx.setEnabled(false);
                    bto.setEnabled(false);
                }
                else{
                    Toast.makeText(MainActivity.this,"Select Player",Toast.LENGTH_SHORT).show();
                }
            }

        });

        bt10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              bt1.setText("");
              bt2.setText("");
              bt3.setText("");
              bt4.setText("");
              bt5.setText("");
              bt6.setText("");
              bt7.setText("");
              bt8.setText("");
              bt9.setText("");
                btx.setEnabled(true);
                bto.setEnabled(true);
                bt1.setEnabled(true);
                bt2.setEnabled(true);
                bt3.setEnabled(true);
                bt4.setEnabled(true);
                bt5.setEnabled(true);
                bt6.setEnabled(true);
                bt7.setEnabled(true);
                bt8.setEnabled(true);
                bt9.setEnabled(true);
                k=0;
                checkvalue=0;
                player[0]="";
                player[1]="";
                pCounter=0;
                pb1.setEnabled(true);
                pb2.setEnabled(true);
                pb1.setText("");
                pb2.setText("");
                pb1.setEnabled(false);
                pb2.setEnabled(false);
                pbs1="";
                pbs2="";
                bt1.setTextColor(Color.BLUE);
                bt2.setTextColor(Color.BLUE);
                bt3.setTextColor(Color.BLUE);
                bt4.setTextColor(Color.BLUE);
                bt5.setTextColor(Color.BLUE);
                bt6.setTextColor(Color.BLUE);
                bt7.setTextColor(Color.BLUE);
                bt8.setTextColor(Color.BLUE);
                bt9.setTextColor(Color.BLUE);
                bt10.setTextColor(Color.BLUE);

            }
        });

        bt11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Main3Activity.class);
                startActivity(intent);
            }
        });
    }

    public void process( int checkvalue2) {
        CharSequence value1 = bt1.getText();
        CharSequence value2 = bt2.getText();
        CharSequence value3 = bt3.getText();
        CharSequence value4 = bt4.getText();
        CharSequence value5 = bt5.getText();
        CharSequence value6 = bt6.getText();
        CharSequence value7 = bt7.getText();
        CharSequence value8 = bt8.getText();
        CharSequence value9 = bt9.getText();

        if (value1.equals(value2) && value2.equals(value3) && !value3.equals("")) {
            compare(bt1, bt2, bt3);
        }
        if (value4.equals(value5) && value5.equals(value6) && !value6.equals("")) {
            compare(bt4, bt5, bt6);
        }
        if (value7.equals(value8) && value8.equals(value9) && !value9.equals("")) {
            compare(bt7, bt8, bt9);
        }
        if (value1.equals(value4) && value4.equals(value7) && !value7.equals("")) {
            compare(bt1, bt4, bt7);
        }
        if (value2.equals(value5) && value5.equals(value8) && !value8.equals("")) {
            compare(bt2, bt5, bt8);
        }
        if (value3.equals(value6) && value6.equals(value9) && !value9.equals("")) {
            compare(bt3, bt6, bt9);
        }
        if (value1.equals(value5) && value5.equals(value9) && !value9.equals("")) {
            compare(bt1, bt5, bt9);
        }
        if (value3.equals(value5) && value5.equals(value7) && !value7.equals("")) {
            compare(bt3, bt5, bt7);
        }
        else {
            if (checkvalue2 == 9) {
                Toast.makeText(MainActivity.this, "Match Tie", Toast.LENGTH_SHORT).show();
            }
        }

    }
    public void compare(Button pp1,Button pp2,Button pp3){
        if(pbs1.equals(value)){
            Toast.makeText(MainActivity.this, s1+" Won the Game", Toast.LENGTH_LONG).show();
            pp1.setTextColor(Color.RED);
            pp2.setTextColor(Color.RED);
            pp3.setTextColor(Color.RED);
            disable();
        }
        else{
            Toast.makeText(MainActivity.this, s2+" Won the Game", Toast.LENGTH_LONG).show();
            pp1.setTextColor(Color.RED);
            pp2.setTextColor(Color.RED);
            pp3.setTextColor(Color.RED);
            disable();
        }
    }
    public void disable(){
        bt1.setEnabled(false);
        bt2.setEnabled(false);
        bt3.setEnabled(false);
        bt4.setEnabled(false);
        bt5.setEnabled(false);
        bt6.setEnabled(false);
        bt7.setEnabled(false);
        bt8.setEnabled(false);
        bt9.setEnabled(false);
    }
}

