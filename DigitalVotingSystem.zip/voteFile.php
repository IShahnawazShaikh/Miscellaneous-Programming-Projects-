<?php
$connect=mysqli_connect("localhost","root","","voteDb");
$v_Id=$_POST['generatedId'];
$Fname=$_POST['Fname'];
$Lname=$_POST['Lname'];
$Pname=$_POST['partyName'];

$query="INSERT INTO `voteList`(`voter_ID`, `F_name`, `L_name`, `Voted_Party`) VALUES ('$v_Id','$Fname','$Lname','$Pname')";
$run=mysqli_query($connect,$query);
echo "<br>First Name=".$Fname;
echo "<br><Last Name=".$Lname;
echo "<br>Voted Party=".$Pname;
echo "<br>generated Voter Id=".$v_Id

// header("Location:http://localhost/VoteSystem/index.php");

?>