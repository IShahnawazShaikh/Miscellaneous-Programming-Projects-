<!DOCTYPE html>
<html>
<head>
	<title>EVM</title>
	<style type="text/css">
  *{
	  margin:0px;
	  padding: 0px;
	}
.main {
    max-width: 1366px;
    width: 100%;
    background-color: gray;
    height: 900px;
    margin: auto;
   }


.symbol {
    width: 100%;
    height: 100%;
    background-color: navajowhite;
    float: left;
    border: 2px solid orange;
}
.symbol nav:nth-child(1) {
    margin-top: 10px;
    margin-left: 13px;
    text-align: center;
}
.symbol nav img{
	border-radius: 51%;
}
.symbol nav:nth-child(2) {
    margin-top: 10px;
    margin-left: 13px;
    text-align: center;
}
.symbol nav:nth-child(2) input {
    margin: 10px;
    height: 24px;
    width: 160px;
    color: white;
    background-color: black;
    box-shadow: 4px 5px 12px red;
}
.symbol form {
    margin-left: 454px;
    margin-top: 57px;
}
.symbol form input {
    display: block;
    text-align: center;
    margin: 21px;
    width: 282px;
    height: 29px;
    background-color: transparent;
    color: currentColor;
    font-size: 20px;
    border-bottom: 2px solid navajowhite;
    border-top: none;
    border-left: none;
    border-right: none;
    box-shadow: 6px 10px 22px;
    background-color: snow;
}
.symbol form input[type="submit"] {
    background-color: deepskyblue;
    font-size: 23px;
}

</style>
</head>
<body>

<?php
 $counter=1;
$connect=mysqli_connect("localhost","root","","voteDb");
$v_Id="ELE20181";
$query2="SELECT * FROM `votelist`";
 $run=mysqli_query($connect,$query2);
    while($data=mysqli_fetch_assoc($run)){
   
     $local=$data['voter_ID'];

      if($v_Id==$local){

      	 $counter=$counter+1;
         
          $v_Id="ELE2018".$counter;
         
      }

   }
?>
	  <div class="main">
	  	<div class="symbol">
	  	 <nav>
	  	 	<img src="images\party1.jpg" height="130" style="width: 13%">
	  	 	<img src="images\party2.jpg" height="130" style="width: 13%">
	  	 	<img src="images\party3.jpg" height="130" style="width: 13%">
	  	 	<img src="images\party4.png" height="130" style="width: 13%">
	  	 	<img src="images\party5.png" height="130" style="width: 13%">
	  	 	<img src="images\party6.png" height="130" style="width: 13%">
	  	 </nav>
	  	  <nav>
	  	    
	  	    <input type="button" name="Congress" value="Congress" onclick="myFunction1()" id="button1">
	  	    <input type="button" name="BJP" value="BJP" onclick="myFunction2()" id="button2">
	  	    <input type="button" name="AAP" value="AAP" onclick="myFunction3()" id="button3">
	  	    <input type="button" name="NCP" value="NCP" onclick="myFunction4()" id="button4">
	  	    <input type="button" name="RJD" value="RJD" onclick="myFunction5()" id="button5">
	  	    <input type="button" name="BSP" value="BSP" onclick="myFunction6()" id="button6">
	  	  </nav>

	  	  <form name="FORM" action="voteFile.php" method="post">

	  	  	<input type="name" name="Fname" placeholder="First Name">
	  	  	<input type="name" name="Lname" placeholder="Last Name">
	  	  	<input type="text" name="partyName" value="" placeholder="Party Name">
	  	  	<input type="text" name="generatedId" value="" placeholder="Voting Id">
	  	  	<input type="submit" name="submit" value="Vote">
	  	  	
	  	  </form>
	  	</div>


	  </div>
</body>
</html>
<script type="text/javascript">
	function myFunction1(){ 
		var generatedVoterId="<?php echo $v_Id?>";
	 document.forms["FORM"]["partyName"].value ="Congress";
	 document.forms["FORM"]["generatedId"].value =""+generatedVoterId;
	
}
function myFunction2(){
	var generatedVoterId="<?php echo $v_Id?>";
	document.forms["FORM"]["partyName"].value ="BJP";
	 document.forms["FORM"]["generatedId"].value =""+generatedVoterId;
	}
	function myFunction3(){
     	var generatedVoterId="<?php echo $v_Id?>";
   document.forms["FORM"]["partyName"].value ="AAP";
  document.forms["FORM"]["generatedId"].value =""+generatedVoterId;
	}
	function myFunction4(){
		var generatedVoterId="<?php echo $v_Id?>";
	document.forms["FORM"]["partyName"].value ="NCP";
	 document.forms["FORM"]["generatedId"].value =""+generatedVoterId;
	}
	function myFunction5(){
		var generatedVoterId="<?php echo $v_Id?>";
	document.forms["FORM"]["partyName"].value ="RJD";
	 document.forms["FORM"]["generatedId"].value =""+generatedVoterId;
	}
	function myFunction6(){
	var generatedVoterId="<?php echo $v_Id?>";
	document.forms["FORM"]["partyName"].value ="BSP";
	 document.forms["FORM"]["generatedId"].value =""+generatedVoterId;
	}
</script>