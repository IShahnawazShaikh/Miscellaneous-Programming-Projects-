package com.example.oasisNav.mail;

/**
 * Created by Mohd Arif on 16-06-2019.
 */

public class Config {
    public static final String EMAIL ="softex.developer4u@gmail.com";
    public static final String PASSWORD ="softdevelopers4u";
}
