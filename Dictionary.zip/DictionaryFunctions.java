import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;
import java.sql.Connection;
class DictionaryFunctions implements ActionListener
{
     
   JFrame frame;
   JTextField [] field=new JTextField[4];
   JLabel label[]=new JLabel[7];
   JTextArea area;
   JLabel background;
   JButton bt1,bt2;
   Connection cn;
   Statement st;
   DictionaryFunctions(){
   	 frame=new JFrame("JM-Dictionary");
     frame.setSize(420,530);
     frame.setLayout(null);

    
     for(int i=0;i<7;i++){
     	 if(i<4){
     	    field[i]=new JTextField();
            frame.add(field[i]);
         }
     	label[i]=new JLabel();
     	  if(i==0){
     	  label[i].setForeground(Color.red);
     	  label[i].setFont(new Font("courier",Font.BOLD,20));
        }
     	else{
     	 label[i].setForeground(Color.black);
         label[i].setFont(new Font("courier",Font.BOLD,14));
       }
        
        frame.add(label[i]);

     }

     label[0].setText("JM-Dictionary");
     label[0].setBounds(110,30,300,30);
    

     label[1].setText("Maintenance Section...");
     label[1].setBounds(133,62,300,14);
     
    
     label[2].setText("Word:");
     label[2].setBounds(40,130,70,25);
     field[0].setBounds(145,130,200,25);

     label[3].setText("Meaning:");
     label[3].setBounds(40,165,100,25);
     field[1].setBounds(145,160,200,25);

    label[4].setText("Synonyms:");
    label[4].setBounds(40,200,100,25);
    field[2].setBounds(145,200,200,25);

    label[5].setText("Antonyms:");
    label[5].setBounds(40,230,100,25);
    field[3].setBounds(145,230,200,25);

    label[6].setText("sentence:");
    label[6].setBounds(40,265,100,25);
    area=new JTextArea();
    area.setBounds(145,260,200,100);
    frame.add(area);
    
    bt1=new JButton("Add Details");
    bt1.setBounds(150,390,100,25);
    frame.add(bt1);

    bt2=new JButton("Backward");
    bt2.setBounds(30,450,100,25);
    frame.add(bt2);
    
    ImageIcon icon=new ImageIcon("3.jpg");    
    Image img=icon.getImage();
    Image img2=img.getScaledInstance(420,530,Image.SCALE_SMOOTH);
      icon=new ImageIcon(img2);
    background=new JLabel("",icon,JLabel.CENTER);
      background.setBounds(0,0,420,530);
    frame.add(background);

     bt1.addActionListener(this);
     bt2.addActionListener(this);
     frame.setVisible(true);
   }
public void actionPerformed(ActionEvent e){
   if(e.getSource()==bt1){
    try{
    	 cn=connection.getConnection();   //Getting Connection
    	st=cn.createStatement();
    	
       //st.executeQuery("create table DictionaryData(Words varchar2(20),Meaning varchar2(100),Synonyms varchar2(30),Antnonyms varchar2(20),Sentence varchar2(300))");
         //st.executeQuery("create table DictionaryWords(Words varchar2(20))");
         st.executeUpdate("INSERT INTO DictionaryWords(Words) VALUES('"+field[0].getText().toLowerCase()+"')");
         st.executeUpdate("INSERT INTO DictionaryData(Words,Meaning,Synonyms,Antnonyms,Sentence) VALUES('"+field[0].getText().toLowerCase()+"','"+field[1].getText().toLowerCase()+"','"+field[2].getText().toLowerCase()+"','"+field[3].getText().toLowerCase()+"','"+area.getText().toLowerCase()+"')"); 
         field[0].setText("");    
         field[1].setText("");    
         field[2].setText("");    
         field[3].setText("");    
         field[4].setText("");    
    }
    catch(Exception sl){}
    finally{
    	try{
  	 	cn.close();
  	 }
  	 catch(Exception ep){}
  	}
  }
  if(e.getSource()==bt2){
  	new dictionary();
  	  frame.dispose();
  }
}
public static void main(String[] args) {
	  new DictionaryFunctions();
	  }
}