import java.sql.*;
import java.sql.Connection;
class connection{
	 public static final Connection getConnection()throws Exception{
	 	    Class.forName("oracle.jdbc.driver.OracleDriver");
			// System.out.println("okie");
			Connection cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","s9716946677s");
			// System.out.println("ok-1");
			// System.out.println(cn);
			return cn;
			// Statement st=cn.createStatement();
	 }
}