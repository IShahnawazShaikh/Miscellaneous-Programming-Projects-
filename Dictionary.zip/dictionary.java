import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.Statement;
class dictionary implements ActionListener
{
   JFrame frame;
   JButton[] button=new JButton[2];
   JLabel label1,label2,label3,background;
   JTextField field1,field2;
   JTextArea field3;
   ResultSet rs;
   Connection cn;
   Statement st;
   String word;
   int counter=0;
    dictionary(){
         frame=new JFrame("JM-Dictionary");
         frame.setSize(420,530);
         frame.setLayout(null);

         label1=new JLabel("JM-Dictionary");
         label1.setBounds(110,30,300,30);
         label1.setForeground(Color.red);
         label1.setFont(new Font("courier",Font.BOLD,20));
         frame.add(label1);

         label2=new JLabel("Happy to help you...");
         label2.setBounds(133,62,300,14);
         label2.setForeground(Color.black);
         label2.setFont(new Font("courier",Font.PLAIN,9));
         frame.add(label2);
      
        field1=new JTextField();        //Search Box
        field1.setBounds(40,100,200,25);
        frame.add(field1);

        for(int i=0;i<2;i++){
           button[i]=new JButton();
           frame.add(button[i]);
        }


       
        button[0].setText("Search");
        button[0].setBounds(245,100,100,25);

        button[1].setText("Admin Section");
        button[1].setBounds(80,400,200,25);
        button[1].addActionListener(this);

        label3=new JLabel("Result...");
        label3.setBounds(40,150,100,14);
        label3.setForeground(Color.black);
        label3.setFont(new Font("courier",Font.BOLD,16));
        frame.add(label3);

        
        field3=new JTextArea();            //Result Box
        field3.setBounds(40,170,313,170);
        field3.setEditable(false);
        frame.add(field3);
        button[0].addActionListener(this);

      ImageIcon icon=new ImageIcon("3.jpg");    
      Image img=icon.getImage();
	  Image img2=img.getScaledInstance(420,530,Image.SCALE_SMOOTH);
      icon=new ImageIcon(img2);
	  background=new JLabel("",icon,JLabel.CENTER);
      background.setBounds(0,0,420,530);
	  frame.add(background);
	  frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
      frame.setVisible(true);

    }
    public void actionPerformed(ActionEvent e){
       if(e.getSource()==button[0]){
       	counter=0;
         field3.setText("");
       	if(field1.getText().equals("")){JOptionPane.showMessageDialog(frame,"Empty Search Box","Alert",JOptionPane.WARNING_MESSAGE);counter=1;}
       	else{  
       	   try{
       	   	cn=connection.getConnection();   //Getting Connection from Connection Class
    	    st=cn.createStatement();
			  rs=st.executeQuery("select * from DictionaryData");
			  while(rs.next()){
			  	    word=rs.getString(1);  //-->First column
			  	  if(word.equals(field1.getText().toLowerCase())){
			  	  	counter++;
			  	  	   field3.append("\n");
			  	  	   field3.append("Meaning: "+rs.getString(2)+"\n"+"\n");
			  	  	   field3.append("synonym: "+rs.getString(3)+"\n"+"\n");
			  	  	   field3.append("Antonynm: "+rs.getString(4)+"\n"+"\n");
			  	  	   field3.append("Sentence: "+rs.getString(5)+"\n"+"\n");
			  	  	  
			  	  }
			  }

			}
			catch(Exception exx){}
			finally{try{
				cn.close();
			}
			catch(Exception ep){}
		  }
		}
		 if(counter==0)
		 JOptionPane.showMessageDialog(frame,"Word Not Found","Alert",JOptionPane.WARNING_MESSAGE);
	}
       if(e.getSource()==button[1]){
          new DictionaryFunctions();
           frame.dispose();
       }
    }
	public static void main(String[] args) {
	  new dictionary();	 
	}
}